<!doctype html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title>Register | SILAB</title>

    <!-- GOOGLE FONT -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />

    <link
      href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap"
      rel="stylesheet"
    />

    <!-- BOOTSTRAP ICONS -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    />

    <!-- CSS AUTHENTICATION -->
    <link rel="stylesheet" href="../../CSS/auth/auth.css" />
  </head>

  <body>
    <main class="register-container">
      <!-- =================================
             BAGIAN KIRI: BACKGROUND DAN LOGO
        ================================== -->

      <section class="visual-panel">
        <!-- BACKGROUND LABORATORIUM -->
        <img
          src="../../Assets/Background.svg"
          alt=""
          class="visual-background"
        />

        <!-- IDENTITAS SILAB -->
        <div class="brand">
          <img
            src="../../Assets/Logo_RPL.svg"
            alt="Logo SILAB"
            class="brand-logo"
          />

          <div class="brand-text">
            <h1>SILAB</h1>

            <p>Sistem Peminjaman Laboratorium</p>

            <p>Universitas Khairun</p>
          </div>
        </div>
      </section>

      <!-- =================================
             BAGIAN KANAN: FORM REGISTER
        ================================== -->

      <section class="register-panel">
        <div class="register-content">
          <!-- HEADER REGISTER -->
          <header class="register-header">
            <h2>Buat Akun</h2>

            <p>Daftar sekarang untuk mulai menggunakan sistem</p>
          </header>

          <!-- FORM REGISTER -->
          <form class="register-form" id="registerForm" novalidate>
            <!-- NAMA LENGKAP -->
            <div class="input-group">
              <i class="bi bi-person"></i>

              <input
                type="text"
                name="nama"
                placeholder="Nama Lengkap"
                autocomplete="name"
                required
              />
            </div>
            <small class="error-message" id="namaError"></small>

            <!-- NIP / NPM -->
            <div class="input-group">
              <i class="bi bi-person"></i>

              <input
                type="text"
                name="identifier"
                placeholder="NIP/NPM"
                inputmode="numeric"
                pattern="[0-9]+"
                title="NIP/NPM hanya boleh berisi angka."
                autocomplete="username"
                required
              />
            </div>
            <small class="error-message" id="identifierError"></small>

            <!-- NOMOR TELEPON -->
            <div class="input-group">
              <i class="bi bi-telephone"></i>

              <input
                type="tel"
                name="no_telp"
                placeholder="No. Telepon"
                inputmode="numeric"
                pattern="[0-9]+"
                title="Nomor telepon hanya boleh berisi angka."
                autocomplete="tel"
                required
              />
            </div>
            <small class="error-message" id="noTelpError"></small>

            <!-- PASSWORD -->
            <div class="input-group">
              <i class="bi bi-lock"></i>

              <input
                type="password"
                id="registerPassword"
                name="password"
                placeholder="Password"
                autocomplete="new-password"
                required
              />

              <button
                type="button"
                class="toggle-password"
                data-target="registerPassword"
                aria-label="Tampilkan password"
                aria-controls="registerPassword"
                aria-pressed="false"
              >
                <i class="bi bi-eye-slash" aria-hidden="true"></i>
              </button>
            </div>
            <small class="error-message" id="passwordError"></small>

            <!-- KONFIRMASI PASSWORD -->
            <div class="input-group">
              <i class="bi bi-lock"></i>

              <input
                type="password"
                id="confirmPassword"
                name="confirm_password"
                placeholder="Konfirmasi Password"
                autocomplete="new-password"
                required
              />

              <button
                type="button"
                class="toggle-password"
                data-target="confirmPassword"
                aria-label="Tampilkan password"
                aria-controls="confirmPassword"
                aria-pressed="false"
              >
                <i class="bi bi-eye-slash" aria-hidden="true"></i>
              </button>
            </div>
            <small class="error-message" id="confirmPasswordError"></small>

            <!-- PERSETUJUAN -->
            <label class="terms">
              <input type="checkbox" name="terms" required />

              <span>
                Saya setuju dengan
                <a href="syarat_ketentuan.html">syarat dan ketentuan</a>
                serta
                <a href="kebijakan_privasi.html">kebijakan privasi</a>
              </span>
            </label>
            <small class="error-message" id="termsError"></small>

            <!-- BUTTON DAFTAR -->
            <button type="submit" class="btn-register">Daftar</button>
          </form>

          <!-- FOOTER REGISTER -->
          <div class="register-footer">
            <p>
              Sudah punya akun?
              <a href="login.php">Login di sini</a>
            </p>
          </div>
        </div>
      </section>
    </main>

    <!-- POP UP PENDAFTARAN BERHASIL -->
    <div class="register-modal" id="registerModal">
      <div class="register-modal-content">
        <!-- IKON BERHASIL -->
        <div class="register-success-icon">
          <i class="bi bi-check-lg"></i>
        </div>

        <!-- JUDUL -->
        <h2>Pendaftaran Berhasil!</h2>

        <!-- DESKRIPSI -->
        <p>
          Akun kamu berhasil didaftarkan dan saat ini sedang menunggu verifikasi
          dari Kepala Laboratorium.
        </p>

        <p class="waiting-info">
          Silakan tunggu hingga akun kamu disetujui. Kamu belum dapat login
          sebelum proses verifikasi selesai.
        </p>

        <!-- TOMBOL OK -->
        <a href="login.php" class="btn-register-ok">OK</a>
      </div>
    </div>

    <!-- STORAGE -->
    <script src="../../JS/shared/storage.js"></script>

    <!-- REGISTRASI -->
    <script src="../../JS/auth/daftar.js"></script>

    <!-- LIHAT PASSWORD -->
    <script src="../../JS/auth/liat_psswd.js"></script>
  </body>
</html>

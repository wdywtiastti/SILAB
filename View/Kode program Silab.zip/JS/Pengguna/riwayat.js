"use strict";

/* =========================================
  ELEMEN HTML
========================================= */

const historyTableBody = document.getElementById("historyTableBody");
const historySearch = document.getElementById("historySearch");
const historyInfo = document.getElementById("historyInfo");

const prevPageButton = document.getElementById("prevPage");
const nextPageButton = document.getElementById("nextPage");

const currentPageElement = document.getElementById("currentPage");
const paginationNumbers = document.getElementById("paginationNumbers");

/* =========================================
  IDENTITAS NAVBAR PENGGUNA
========================================= */

function tampilkanIdentitasNavbar() {
  const sesi = sesiSILAB.ambil();

  if (!sesi || sesi.role !== "pengguna") {
    window.location.href = "../auth/login.html";
    return null;
  }

  const users = SILABStorage.get(SILABStorage.KEYS.USERS, []);

  if (!Array.isArray(users)) return null;

  const akun = users.find(
    (user) => String(user.nipNpm).trim() === String(sesi.identifier).trim(),
  );

  if (!akun || akun.status !== "aktif") {
    window.location.href = "../auth/login.html";
    return null;
  }

  const navbarName = document.getElementById("userNavbarName");
  const profileName = document.getElementById("profileUserName");

  if (navbarName) navbarName.textContent = akun.nama;
  if (profileName) profileName.textContent = akun.nama;

  return akun;
}

/* =========================================
   KONFIGURASI
========================================= */

const itemsPerPage = 5;

let currentPage = 1;
let currentHistoryData = [];
let allUserHistory = [];

/* =========================================
   VALIDASI ELEMEN
========================================= */

function validateHistoryElements() {
  const requiredElements = [
    historyTableBody,
    historyInfo,
    prevPageButton,
    nextPageButton,
    paginationNumbers,
  ];

  return requiredElements.every(Boolean);
}

/* =========================================
   HELPER STRING
========================================= */

function safeString(value) {
  return typeof value === "string" ? value : "";
}

/* =========================================
   PENCARIAN RIWAYAT
========================================= */

function searchHistory() {
  const keyword = safeString(historySearch?.value).trim().toLowerCase();

  const filteredHistory = allUserHistory.filter((data) => {
    const namaKegiatan = safeString(
      data.namaKegiatan || data.nama,
    ).toLowerCase();

    const kategori = safeString(data.kategori).toLowerCase();

    return namaKegiatan.includes(keyword) || kategori.includes(keyword);
  });

  currentPage = 1;

  renderHistory(filteredHistory);
}

/* =========================================
   MENAMPILKAN RIWAYAT
========================================= */

function renderHistory(historyData) {
  if (!historyTableBody) return;

  currentHistoryData = Array.isArray(historyData) ? historyData : [];

  const totalData = currentHistoryData.length;

  const totalPages = Math.ceil(totalData / itemsPerPage);

  if (totalPages === 0) {
    currentPage = 1;
    showEmptyHistory("Data riwayat tidak ditemukan.");
    updatePagination(0, 0, 0);
    return;
  }

  if (currentPage > totalPages || currentPage < 1) {
    currentPage = 1;
  }

  historyTableBody.innerHTML = "";

  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = Math.min(startIndex + itemsPerPage, totalData);

  const pageData = currentHistoryData.slice(startIndex, endIndex);

  pageData.forEach((submission) => {
    historyTableBody.appendChild(createHistoryRow(submission));
  });

  updatePagination(currentPage, totalPages, totalData);
}

/* =========================================
   UPDATE PAGINATION
========================================= */

function updatePagination(page, totalPages, totalData) {
  if (!historyInfo) return;

  const start = totalData === 0 ? 0 : (page - 1) * itemsPerPage + 1;

  const end = Math.min(page * itemsPerPage, totalData);

  historyInfo.textContent = `Menampilkan ${start}–${end} dari ${totalData} pengajuan`;

  if (prevPageButton) {
    prevPageButton.disabled = page <= 1 || totalPages === 0;
  }

  if (nextPageButton) {
    nextPageButton.disabled = page >= totalPages || totalPages === 0;
  }

  if (currentPageElement) {
    currentPageElement.textContent =
      totalPages === 0 ? "0" : `${page} / ${totalPages}`;
  }

  renderPaginationNumbers(totalPages);
}

/* =========================================
   NAVIGASI HALAMAN
========================================= */

function changePage(direction) {
  const totalPages = Math.ceil(currentHistoryData.length / itemsPerPage);

  const nextPage = currentPage + direction;

  if (nextPage < 1 || nextPage > totalPages) {
    return;
  }

  currentPage = nextPage;

  renderHistory(currentHistoryData);
}

/* =========================================
   FORMAT TANGGAL
========================================= */

function formatDate(dateValue) {
  if (!dateValue) return "-";

  const date = new Date(dateValue);

  if (Number.isNaN(date.getTime())) return "-";

  return date.toLocaleDateString("id-ID", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  });
}

/* =========================================
   FORMAT WAKTU
========================================= */

function formatTime(dateValue) {
  if (!dateValue) return "-";

  const date = new Date(dateValue);

  if (Number.isNaN(date.getTime())) return "-";

  return date.toLocaleTimeString("id-ID", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}

/* =========================================
   LABEL STATUS
========================================= */

function getStatusLabel(status) {
  const statusLabels = {
    menunggu_verifikasi: "Menunggu",
    menunggu: "Menunggu",
    direkomendasikan: "Direkomendasikan",
    disetujui: "Disetujui",
    ditolak: "Ditolak",
    dibatalkan: "Dibatalkan",
    selesai: "Selesai Digunakan",
  };

  return statusLabels[status] || status || "Tidak diketahui";
}

/* =========================================
   TABEL KOSONG
========================================= */

function showEmptyHistory(message) {
  if (!historyTableBody) return;

  historyTableBody.innerHTML = "";

  const row = document.createElement("tr");
  const cell = document.createElement("td");

  cell.colSpan = 4;
  cell.textContent = message;
  cell.style.textAlign = "center";
  cell.style.padding = "25px";

  row.appendChild(cell);
  historyTableBody.appendChild(row);
}

/* =========================================
   MEMBUAT BARIS RIWAYAT
========================================= */

function createHistoryRow(data) {
  const row = document.createElement("tr");

  // Kolom 1: Tanggal pengajuan
  const dateCell = document.createElement("td");
  dateCell.textContent = formatDate(data.createdAt);

  // Kolom 2: Waktu kegiatan
  const timeCell = document.createElement("td");
  timeCell.textContent = `${formatTime(data.waktuMulai)} - ${formatTime(data.waktuSelesai)}`;

  // Kolom 3: Nama kegiatan dan kategori
  const activityCell = document.createElement("td");

  const activityName = document.createElement("strong");
  activityName.textContent = safeString(data.namaKegiatan || data.nama) || "-";

  const categoryName = document.createElement("small");
  categoryName.textContent = safeString(data.kategori) || "-";

  categoryName.style.display = "block";

  activityCell.append(activityName, categoryName);

  // Kolom 4: Status pengajuan
  const statusCell = document.createElement("td");

  const statusBadge = document.createElement("span");

  const statusClasses = {
    menunggu_verifikasi: "status-pending",
    menunggu: "status-pending",
    direkomendasikan: "status-recommended",
    disetujui: "status-approved",
    ditolak: "status-rejected",
    dibatalkan: "status-cancelled",
    selesai: "status-completed",
  };

  statusBadge.className = `status-badge ${statusClasses[data.status] || "status-pending"}`;

  statusBadge.textContent = getStatusLabel(data.status);

  statusCell.appendChild(statusBadge);

  // Masukkan hanya empat kolom
  row.append(dateCell, timeCell, activityCell, statusCell);

  return row;
}

function tampilkanIdentitasNavbar() {
  const sesi = sesiSILAB.ambil();

  if (!sesi || sesi.role !== "pengguna") {
    window.location.href = "../auth/login.html";
    return null;
  }

  const users = SILABStorage.get(SILABStorage.KEYS.USERS, []);

  const akun = users.find(
    (user) => String(user.nipNpm).trim() === String(sesi.identifier).trim(),
  );

  if (!akun || akun.status !== "aktif") {
    window.location.href = "../auth/login.html";
    return null;
  }

  const navbarName = document.getElementById("userNavbarName");
  const profileName = document.getElementById("profileUserName");

  if (navbarName) navbarName.textContent = akun.nama;
  if (profileName) profileName.textContent = akun.nama;

  return akun;
}

/* =========================================
   NOMOR HALAMAN COMPACT
========================================= */

function renderPaginationNumbers(totalPages) {
  if (!paginationNumbers) return;

  paginationNumbers.innerHTML = "";

  if (totalPages === 0) return;

  // Menentukan maksimal 3 nomor halaman berurutan
  const startPage = Math.max(1, Math.min(currentPage - 1, totalPages - 2));

  const endPage = Math.min(totalPages, startPage + 2);

  for (let page = startPage; page <= endPage; page++) {
    const button = document.createElement("button");

    button.type = "button";
    button.className = "pagination-number";
    button.textContent = page;

    if (page === currentPage) {
      button.classList.add("active");
      button.setAttribute("aria-current", "page");
    }

    button.addEventListener("click", () => {
      currentPage = page;
      renderHistory(currentHistoryData);
    });

    paginationNumbers.appendChild(button);
  }
}

/* =========================================
   MEMUAT RIWAYAT DARI DATABASE MYSQL
========================================= */

async function loadHistory() {
  if (!historyTableBody) return;

  historyTableBody.innerHTML = "";

  showEmptyHistory("Memuat riwayat pengajuan...");

  try {
    const response = await fetch("API_pengajuan.php?action=history", {
      method: "GET",
      credentials: "same-origin",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    });

    const result = await response.json();

    if (!response.ok || !result.success) {
      throw new Error(result.message || "Gagal mengambil riwayat.");
    }

    allUserHistory = Array.isArray(result.data.history)
      ? result.data.history
      : [];

    // Urutkan berdasarkan waktu terbaru.
    allUserHistory.sort((a, b) => {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

    currentPage = 1;

    if (allUserHistory.length === 0) {
      showEmptyHistory("Kamu belum memiliki riwayat pengajuan.");

      updatePagination(0, 0, 0);

      return;
    }

    renderHistory(allUserHistory);
  } catch (error) {
    console.error("Gagal memuat riwayat:", error);

    allUserHistory = [];
    currentHistoryData = [];
    currentPage = 1;

    showEmptyHistory(
      "Gagal mengambil data riwayat. Silakan muat ulang halaman.",
    );

    updatePagination(0, 0, 0);
  }
}

/* =========================================
   INISIALISASI
========================================= */

function initHistory() {
  if (!validateHistoryElements()) {
    console.error("Elemen HTML riwayat tidak ditemukan.");

    return;
  }

  // Pencarian
  if (historySearch) {
    historySearch.addEventListener("input", searchHistory);
  }

  // Halaman sebelumnya
  prevPageButton.addEventListener("click", () => {
    changePage(-1);
  });

  // Halaman selanjutnya
  nextPageButton.addEventListener("click", () => {
    changePage(1);
  });

  // Ambil data dari database
  loadHistory();
}

// Jalankan setelah DOM tersedia
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initHistory);
} else {
  initHistory();
}
